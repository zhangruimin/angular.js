function FooController() {
  var MAX = 5000;
  this.persons = ["a", "b"];
  this.persons2 = [];
  this.clear = function(){
    this.persons2 = [];
  }
  for (var i = 1; i < MAX; i++) {
    this.persons2.push({
      Name:"Zhang Ruimin" ,
      Gender:"Male",
      Description:"Good Man",
      Birthday:"1988.08.25",
      Engagement:"ThoughtWorks",
      LastName:"Zhang"
    });
  }
}
